# ========================= Create weapon class to define weapon attributes =============================
class Weapon:
    def __init__(self, name, damage, defense_modifier, accuracy, skillchain, element, weakness, tp, tp_modifier, status_effect):
        self.name = name
        self.damage = damage
        self.defense_modifier = defense_modifier
        self.weapon_accuracy = accuracy
        self.skillchain = skillchain
        self.element = element
        self.weakness = weakness
        self.tp_modifier = tp_modifier
        self.tp = tp
        self.status_effect = status_effect
        self.main_weapon = None
        self.offhand_weapon = None

# ========================= Create weapons list =============================

# ============================ SWORD =========================================== #

main_weapon_sword = Weapon(
    # Balanced weapon
    name='sword',
    damage=5,
    defense_modifier=2,
    accuracy=5,
    skillchain="Pink_blossom_blade",
    element="fire",
    weakness='water',
    tp_modifier=2,
    tp= 5,
    status_effect="burn"
)

main_weapon_name = main_weapon_sword.name   

offhand_weapon_shield = Weapon(
    name='shield',
    damage = 0,
    defense_modifier = 5,
    accuracy= 0,
    skillchain=None,
    element= None,
    weakness=None,
    tp_modifier=10,
    tp = 0,
    status_effect=None
)

offhand_weapon_name = offhand_weapon_shield.name

offhand_weapon_sword = Weapon(
    # Balanced weapon
    name='sword',
    damage=5,
    defense_modifier=2,
    accuracy=5,
    skillchain="Pink_blossom_blade",
    element="fire",
    weakness='water',
    tp_modifier=2,
    tp= 5,
    status_effect="burn"
)

offhand_weapon_name = offhand_weapon_sword.name

offhand_weapon_dagger = Weapon(
    # Lighter damage and defense_modifier but higher accuracy.
    name='dagger',
    damage=3,
    defense_modifier=1,
    accuracy=9,
    skillchain="Wisp_bee_sting",
    element="wind",
    weakness='earth',
    tp_modifier=1,
    tp= 5,
    status_effect="lower accucery"
)

offhand_weapon_name = offhand_weapon_dagger.name

offhand_weapon_axe = Weapon(
    name='axe',
    damage=6,
    defense_modifier=2,
    accuracy=6,
    skillchain="Storm_render",
    element="lighten",
    weakness="water",
    tp_modifier=2,
    tp= 0,
    status_effect="shock",
)

offhand_weapon_name = offhand_weapon_axe.name

offhand_weapon_staff = Weapon(
    name='staff',
    damage=7,
    defense_modifier=0,
    accuracy=4,
    skillchain="banshee_kiss",
    element="psychic",
    weakness=None,
    tp_modifier=4,
    tp= 0,
    status_effect="filling MP",
)

offhand_weapon_name = offhand_weapon_staff.name

offhand_weapon_fists = Weapon(
     name='fists',
    damage=2,
    defense_modifier=0,
    accuracy=6,
    skillchain="Bear_claw_pommel",
    element="earth",
    weakness='water',
    tp_modifier=5,
    tp=5,
    status_effect="stun"
)

offhand_weapon_name = offhand_weapon_fists.name

# ======================================== DAGGER ============================================= #

main_weapon_dagger = Weapon(
    # Lighter damage and defense_modifier but higher accuracy.
    name='dagger',
    damage=3,
    defense_modifier=1,
    accuracy=9,
    skillchain="Wisp_bee_sting",
    element="wind",
    weakness='earth',
    tp_modifier=1,
    tp= 5,
    status_effect="lower accucery"
)



offhand_weapon_shield = Weapon(
    name='shield',
    damage = 0,
    defense_modifier = 5,
    accuracy= 0,
    skillchain=None,
    element= None,
    weakness=None,
    tp_modifier=10,
    tp = 0,
    status_effect=None
)


offhand_weapon_dagger = Weapon(
     # Lighter damage and defense_modifier but higher accuracy.
    name='dagger',
    damage=3,
    defense_modifier=1,
    accuracy=9,
    skillchain="Wisp_bee_sting",
    element="wind",
    weakness='earth',
    tp_modifier=1,
    tp= 5,
    status_effect="lower accucery"
)


offhand_weapon_fists = Weapon(
     name='fists',
    damage=2,
    defense_modifier=0,
    accuracy=6,
    skillchain="Bear_claw_pommel",
    element="earth",
    weakness='water',
    tp_modifier=5,
    tp=5,
    status_effect="stun"
)


# =========================================================== MACE ========================================== #

main_weapon_mace = Weapon(
    # heavier damage but lower accuracy
    name='mace',
    damage=10,
    defense_modifier=3,
    accuracy=1,
    skillchain="Bubble_gum_blast",
    element="water",
    weakness='fire',
    tp_modifier=3,
    tp= 5,
    status_effect="poison"
)   


offhand_weapon_shield = Weapon(
    name='shield',
    damage = 0,
    defense_modifier = 5,
    accuracy= 0,
    skillchain=None,
    element= None,
    weakness=None,
    tp_modifier=10,
    tp = 0,
    status_effect=None
)

# ======================================================= FISTS ===================================================== #

main_weapon_fists = Weapon(
    name='fists',
    damage=2,
    defense_modifier=0,
    accuracy=6,
    skillchain="Bear_claw_pommel",
    element="earth",
    weakness='water',
    tp_modifier=5,
    tp=5,
    status_effect="stun"
)


offhand_weapon_fists = Weapon(
     name='fists',
    damage=2,
    defense_modifier=0,
    accuracy=6,
    skillchain="Bear_claw_pommel",
    element="earth",
    weakness='water',
    tp_modifier=5,
    tp=5,
    status_effect="stun"
)


# ========================================================= STAFF ================================================= #

main_weapon_staff = Weapon(
    name='staff',
    damage=7,
    defense_modifier=0,
    accuracy=4,
    skillchain="banshee_kiss",
    element="psychic",
    weakness=None,
    tp_modifier=4,
    tp= 0,
    status_effect="filling MP",
)


offhand_weapon_fists = Weapon(
     name='fists',
    damage=2,
    defense_modifier=0,
    accuracy=6,
    skillchain="Bear_claw_pommel",
    element="earth",
    weakness='water',
    tp_modifier=5,
    tp=5,
    status_effect="stun"
)


offhand_weapon_sword = Weapon(
    # Balanced weapon
    name='sword',
    damage=5,
    defense_modifier=2,
    accuracy=5,
    skillchain="Pink_blossom_blade",
    element="fire",
    weakness='water',
    tp_modifier=2,
    tp= 5,
    status_effect="burn"
)


# ================================================================= AXE ============================================= #

main_weapon_axe = Weapon(
    name='axe',
    damage=6,
    defense_modifier=2,
    accuracy=6,
    skillchain="Storm_render",
    element="lighten",
    weakness="water",
    tp_modifier=2,
    tp= 0,
    status_effect="shock",
)


offhand_weapon_sword = Weapon(
    # Balanced weapon
    name='sword',
    damage=5,
    defense_modifier=2,
    accuracy=5,
    skillchain="Pink_blossom_blade",
    element="fire",
    weakness='water',
    tp_modifier=2,
    tp= 5,
    status_effect="burn"
)


offhand_weapon_shield = Weapon(
    name='shield',
    damage = 0,
    defense_modifier = 5,
    accuracy= 0,
    skillchain=None,
    element= None,
    weakness=None,
    tp_modifier=10,
    tp = 0,
    status_effect=None
)


offhand_weapon_axe = Weapon(
     name='axe',
    damage=6,
    defense_modifier=2,
    accuracy=6,
    skillchain="Storm_render",
    element="lighten",
    weakness="water",
    tp_modifier=2,
    tp= 0,
    status_effect="shock",
)


offhand_weapon_dagger = Weapon(
     # Lighter damage and defense_modifier but higher accuracy.
    name='dagger',
    damage=3,
    defense_modifier=1,
    accuracy=9,
    skillchain="Wisp_bee_sting",
    element="wind",
    weakness='earth',
    tp_modifier=1,
    tp= 5,
    status_effect="lower accucery"
)


# Compiled list of Weapons
main_weapons_list =[main_weapon_dagger, main_weapon_mace, main_weapon_sword, main_weapon_fists, main_weapon_staff, main_weapon_axe]
offhand_weapons_list =[offhand_weapon_dagger, offhand_weapon_sword, offhand_weapon_shield, offhand_weapon_fists, offhand_weapon_staff, offhand_weapon_axe]
# Look to have a Player class that will hold player and computer information. 
# Used to help determine outcome so that weapons will aid the user rather than become the outcome.