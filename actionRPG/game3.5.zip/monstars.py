import weapon
import random

class Monstars:
    def __init__(self, name, AC, hp, tp, mp, stre, dex, vit, agi, mind, wis, cha, num_attack, main_weapon, offhand_weapon) -> None:
        self.name = name
        self.hp = hp

        self.tp = tp
        self.mp = mp
        self.AC = AC
        self.stre = stre
        self.dex = dex
        self.vit = vit
        self.agi = agi
        self.mind = mind
        self.wis = wis
        self.cha = cha
        self.successful_hits = 0
        self.accuracy_modifier = self.dex + self.agi
        self.num_attack = num_attack
        self.weapon_accuracy = []
        self.main_weapon = main_weapon
        self.offhand_weapon = offhand_weapon
        self.element_weakness = []
        self.status_effect = {}
        self.accuracy = 0
        # self.Attacks = num_attack
        # self.stats = monstars_stats


    
    def Equip(self, main_weapon, offhand_weapon):
        if main_weapon is not None and offhand_weapon is not None:
            self.main_weapon = main_weapon
            self.offhand_weapon = offhand_weapon
            
        else:
                print("Please provide both main and offhand weapons")

    # Normal Attack
    def Attack(self, target):
        hit_calc = (int(self.accuracy_modifier) + int(self.main_weapon.weapon_accuracy)) >= target.AC
        damage = self.main_weapon.damage

        # If attack hits target
        if hit_calc: 
            self.tp += 5
            self.successful_hits += 1
            if self.offhand_weapon == weapon.offhand_weapon_shield:
                damage_blocked = self.block_with_shield(target)
                target.hp -= damage_blocked
            elif self.main_weapon == weapon.main_weapon_sword or self.main_weapon == weapon.main_weapon_dagger:
                self.parry_with_sword_or_dagger(target)
            elif self.main_weapon == weapon.main_weapon_fists:
                damage_dealt = self.counter_punch_with_fists()
                target.hp -= damage_dealt
                # Counter attack with fists for 5 damge if successful counter
                if hit_calc:
                    print(f"{target.name} counter attacks with a punch!")
                self.hp -= 5

            
            target.hp -= damage
            print(f'{self.name} hits {target.name} for {self.main_weapon.damage} damage!')
            
        else:
            # If attack misses target
            print(f'\n{self.name} missed the target!')

    # def multi_attacks(self, num_attack, target):
    #     total_damage = 0
    #     for _ in range(num_attack):
    #           main_hit_chance =(int(self.accuracy_modifier) + int(self.main_weapon.accuracy)) >= target.AC
    #           offhand_hit_chance = (int(self.accuracy_modifier) + int(self.offhand_weapon.accuracy)) >= target.AC

    #           if main_hit_chance and offhand_hit_chance:
    #             # Both attacks hit
    #             print(f"{self.name} attacks with {self.main_weapon.name} and {self.offhand_weapon.name}!")
    #             main_damage = self.main_weapon.damage
    #             offhand_damage = self.offhand_weapon.damage
    #             total_damage += main_damage + offhand_damage
    #             target.hp -= main_damage
    #             target.hp -= offhand_damage
    #             self.tp += 5
    #             self.successful_hits += 2
    #           elif main_hit_chance:
    #                # Only main hand attack hits
    #                print(f"{self.name} attacks with {self.main_weapon.name}!")
    #                total_damage += self.main_weapon.damage
    #                target.hp -= self.offhand_weapon.damage
    #                self.tp +=5
    #                self.successful_hits += 1
    #           elif offhand_hit_chance:
    #                # Only offhand attack hits
    #                print(f"{self.name} attacks with {self.offhand_weapon.name}!")
    #                total_damage += self.offhand_weapon.damage
    #                target.hp -= self.main_weapon.damage
    #                self.tp += 5
    #                self.successful_hits += 1
    #           else:
    #                # Both attacks miss
    #                print(f"{self.name}misses the attacks with both weapons!")

    #     return target.hp, total_damage

   
    def block_with_shield(self,target):
            # SHIELD BLOCKING LOGIC
                  roll = random.randint(1, 20) + self.weapon.defense_modifier
                  if roll >= 10:
                    self.block_with_shield(target)
                    print(f"{self.name} blocks with the shield!")
                  else:
                    print(f"{self.offhand_weapon.name} fails to block the attack!")
                    
            # Assuming shield bash does 3 damage
            # return 3

    def parry_with_sword_or_dagger(self, target):
        roll = random.randint(1, 20) + self.weapon.defense_modifier
        if roll >= 10:
            print(f"{self.name} successfully parries the attack!")
            return True
        else:
            print(f"{self.name} fails to perry the attack!")
        # while self.hp > 0 and target.hp > 0:
            # Player 2 attacks Player 1
            roll = random.randint(1, 20) + self.weapon.defense_modifier
            if roll >= target.AC:
                print(f"{target.name} hits {self.profession.name}!")
                # Player1 attempts to parry
                if not self.parry_with_sword_or_dagger(target):
                     # If parry fails, Player2 deals damage
                    #  self.hp -= random.randint(1, 10) #Assuming damge is 1-10
                     print(f"{target.name} deals damage to {self.name}. {self.name} HP: {self.hp}")
            # if (random.randint(1, 20)+ self.weapon.defense_modifier) >= 20:
            #     print(f"{self.name} parries with the sword/dagger!")
                # Assuming parry deals no damge but adds a status effect for the next attack
            # self.status_effects.update({'parry':0})

    def counter_punch_with_fists(self):
            print(f"{self.name} counters with a punch!")
            # Assuming counter punch deals 5 damage
            return 5
    



            
    

# =============================================== Monstars ===================================================================== #

goblin_boss = Monstars(name="Goblin Boss",
                  AC=17,
                  hp=1421,
                  tp=0,
                  mp=0,
                  stre=10,
                  dex=14,
                  vit=10,
                  agi=16,
                  mind=10,
                  wis=8,
                  cha=10,
                  num_attack=3,
                  main_weapon=weapon.main_weapon_sword,
                  offhand_weapon=weapon.offhand_weapon_axe,
                  )

goblin = Monstars(name="Goblin",
                  AC=10,
                  hp=1500,
                  tp=0,
                  mp=0,
                  stre=10,
                  dex=10,
                  vit=10,
                  agi=10,
                  mind=10,
                  wis=10,
                  cha=10,
                  num_attack=2,
                  main_weapon= weapon.main_weapon_dagger,
                  offhand_weapon=weapon.offhand_weapon_shield,
                  )

goblin_mage = Monstars(name="goblin Mage",
                  AC=10,
                  hp=1300,
                  tp=0,
                  mp=100,
                  stre=5,
                  dex=10,
                  vit=10,
                  agi=10,
                  mind=16,
                  wis=11,
                  cha=10,
                  num_attack=1,
                  main_weapon=weapon.main_weapon_staff,
                  offhand_weapon=weapon.offhand_weapon_fists,
                  )
orge = Monstars(name="Orge",
                AC=11,
                hp=1459,
                tp=0,
                mp=0,
                stre=19,
                dex=8,
                vit=16,
                agi=8,
                mind=5,
                wis=7,
                cha=7,
                num_attack= 4,
                main_weapon=weapon.main_weapon_mace,
                offhand_weapon=weapon.offhand_weapon_fists,
                )
bugbear = Monstars(name="Bugbear Chief",
                   AC=17,
                   hp=1465,
                   tp=0,
                   mp=0,
                   stre=17,
                   dex=14,
                   vit=15,
                   agi=13,
                   mind=14,
                   wis=11,
                   cha=12,
                   num_attack=3,
                   main_weapon=weapon.main_weapon_axe,
                   offhand_weapon=weapon.offhand_weapon_sword,
                   )
gnoll = Monstars(name="Gnoll Fang of Yeet",
                 AC=14,
                 hp=1465,
                 tp=0,
                 mp=0,
                 stre=16,
                 dex=14,
                 vit=15,
                 agi=15,
                 mind=6,
                 wis=10,
                 cha=7,
                 num_attack=2,
                 main_weapon=weapon.main_weapon_axe,
                 offhand_weapon=weapon.offhand_weapon_axe,
                 )
troll =Monstars(name="Troll",
                 AC=15,
                 hp=1484,
                 tp=0,
                 mp=0,
                 stre=18,
                 dex=13,
                 vit=20,
                 agi=11,
                 mind=7,
                 wis=9,
                 cha=7,
                 num_attack=4,
                 main_weapon=weapon.main_weapon_axe,
                 offhand_weapon=weapon.offhand_weapon_shield,
                 )
monstars_list =[goblin_boss, goblin, goblin_mage, orge, bugbear, gnoll, troll]
# monstars_stats = {
#      'goblin' : (10,14,10,16,10,8,10),
#     'orge' : ( 19,8,16,8,5,7,7),
#     'bugbear': (17,14,15,13,14,11,12),
#     'gnoll': (16,14,15,15,6,10,7),
#     'troll': (18,13,20,11,7,9,7),
# }

# goblin = monstars(
#       name="Goblin",
#       AC=10,
#       hp=1500,
#       stre=10,
#       dex=10,
#       vit=10,
#       agi=10,
#       inte=10,
#       wis=10,
#       cha=10,
#       num_attack=2,
#       weapon=weapon.dagger
# )