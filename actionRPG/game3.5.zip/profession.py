

class Profess:
    def __init__(self, name, element_res, accuracy, AC) -> None:
        self.name = name
        self.element_res = element_res
        self.accuracy = accuracy
        self.AC = AC

# ================================================= Professions ============================================================== #
    
Knight = Profess(name="Knight",
                 element_res= "earth",
                 accuracy= 10,
                 AC= 17,
                 )
Wizard = Profess(name="Wizard",
                 element_res="wind",
                 accuracy= 10,
                 AC= 12,
                 )
Rogue = Profess(name="Rogue",
                element_res="water",
                accuracy= 10,
                AC=10,
                )
Cleric = Profess(name="Cleric",
                 element_res="fire",
                 accuracy= 10,
                 AC= 16,
                 )
Druid = Profess(name="Druid",
                element_res="",
                accuracy= 10,
                AC=13,
                )
Artificer = Profess(name="Artificer",
                    element_res="",
                    accuracy=10,
                    AC= 13,
                )
Profession_list =[Knight,Wizard,Rogue,Cleric,Druid,Artificer]